# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 0.22.0 (2024-11-27)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.21.4](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.21.3...v0.21.4) (2024-11-27)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.21.3](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.21.2...v0.21.3) (2024-11-27)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.21.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.21.1...v0.21.2) (2024-11-18)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.21.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.21.0...v0.21.1) (2024-10-08)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.21.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.20.4...v0.21.0) (2024-09-30)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.20.4](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.20.3...v0.20.4) (2024-09-24)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.20.3](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.20.2...v0.20.3) (2024-08-12)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.20.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.20.1...v0.20.2) (2024-06-05)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.20.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.20.0...v0.20.1) (2024-04-04)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.20.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.19.1...v0.20.0) (2024-03-28)


### Bug Fixes

* получение объекта .getValue ([af63007](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/af630079d77cde4f54bed6b99c2dd52943f92348))





# [0.19.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.18.1...v0.19.0) (2024-03-07)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.18.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.18.0...v0.18.1) (2024-02-29)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.18.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.17.0...v0.18.0) (2024-01-31)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.17.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.16.2...v0.17.0) (2024-01-22)


### Bug Fixes

* visibility ([865d1fd](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/865d1fd48e86de265fc58dff878a441db74830a4))





## [0.16.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.16.1...v0.16.2) (2023-11-27)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.16.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.16.0...v0.16.1) (2023-10-31)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.16.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.15.0...v0.16.0) (2023-10-23)


### Features

* добавлены методы `findInherited` и `getInherited` в `PdfDictionary` ([28ee8a0](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/28ee8a060ffcfe3ee107132685e7cf108ab254dd))





# [0.15.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.14.0...v0.15.0) (2023-10-23)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.14.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.13.2...v0.14.0) (2023-10-23)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.13.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.13.1...v0.13.2) (2023-10-12)


### Bug Fixes

* minor fixes ([c4900fc](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/c4900fcdc1f468dfd25f804bde896ef1cd900fca))





## [0.13.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.13.0...v0.13.1) (2023-10-06)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.13.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.12.2...v0.13.0) (2023-10-04)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.12.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.11.1...v0.12.0) (2023-09-26)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.11.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.11.0...v0.11.1) (2023-09-13)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.11.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.9...v0.11.0) (2023-09-05)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.9](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.8...v0.10.9) (2023-08-22)


### Bug Fixes

* расширена проверка подписи ([b55c255](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/b55c25596e1b09d91fc3c3000794843ddd6f6e0a))





## [0.10.8](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.7...v0.10.8) (2023-08-21)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.7](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.6...v0.10.7) (2023-08-09)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.6](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.5...v0.10.6) (2023-07-17)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.5](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.4...v0.10.5) (2023-07-14)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.4](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.3...v0.10.4) (2023-07-04)


### Bug Fixes

* offset 0 ([6634e6e](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/6634e6e1066b390a9695756e056e4006815e06d9))





## [0.10.3](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.2...v0.10.3) (2023-07-04)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.1...v0.10.2) (2023-06-21)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.10.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.10.0...v0.10.1) (2023-06-20)


### Bug Fixes

* Добавление свойства visibility в Signature ([a208abd](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/a208abd62baac39cda3e9e924a83aec05f000b23))





# [0.10.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.9.1...v0.10.0) (2023-06-19)


### Features

* добавлен метод `pageNumber` для `Signature` ([b9fd5aa](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/b9fd5aa2c0a1ba429cc876ee6e6956746b18dccf))





# [0.9.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.6...v0.9.0) (2023-06-06)


### Features

* добавить поддержку png изображений ([c4c2fa0](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/c4c2fa00fe195c6f3f901b4e57ff9565fa13145e))





## [0.8.6](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.5...v0.8.6) (2023-06-02)


### Bug Fixes

* имя подписи не должно быть пустым ([3be08eb](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/3be08eb3fbb2c43100694b00889609af35db9fae))





## [0.8.5](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.4...v0.8.5) (2023-05-30)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.8.4](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.3...v0.8.4) (2023-05-29)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.8.3](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.2...v0.8.3) (2023-05-29)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.8.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.1...v0.8.2) (2023-05-17)


### Bug Fixes

* Перепутаны высота и ширина для блока подписи ([c30314d](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/c30314d3880c409a130b3727c16c2e2e4300d502))





## [0.8.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.8.0...v0.8.1) (2023-05-17)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.8.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.7.2...v0.8.0) (2023-05-17)


### Features

* добавление TrustedParams для хранения JSON ([c07d5fd](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/c07d5fd0925993c9609b3cf0d2261b69403afc49))





## [0.7.2](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.7.1...v0.7.2) (2023-05-16)

**Note:** Version bump only for package @trusted-pdf/sign





## [0.7.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.7.0...v0.7.1) (2023-05-15)


### Bug Fixes

* Неправильный Prev в XRef ([16384f4](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/16384f4e14e13a686366fc27340c5a3d96caa641))





# [0.7.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.6.0...v0.7.0) (2023-05-11)


### Bug Fixes

* merge ([d70d90b](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/d70d90bc30ba98dd0805935c97a51480aa1d2c80))
* удаление дублирующихся методов ([d8d239c](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/d8d239cdc20323771cb7972f17cc6a8bdfec34bc))


### Features

* проверка документа на изменения после подписания ([8bb1c08](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/8bb1c08a72f52eb4dbf1e60b4ca3aaad61ae99b7))





# [0.6.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.5.0...v0.6.0) (2023-05-11)


### Features

* копирование PDF документа с применением фильтров ([c1d9f1f](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/c1d9f1faabc8c05afc9a290f27c0f755d730d07e))





# [0.5.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.4.1...v0.5.0) (2023-04-14)


### Features

* Добавление поддержки XRefStream структуры ([5b2c68f](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/5b2c68f2ee6a7f2d8f9145a4ece17d511efd091f))





## [0.4.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.4.0...v0.4.1) (2023-04-04)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.4.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/v0.3.0...v0.4.0) (2023-03-14)

**Note:** Version bump only for package @trusted-pdf/sign





# 0.3.0 (2023-03-10)


### Features

* Добавление API для Подписи/Проверки ([f7c2da4](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/f7c2da496af598d82e355c4fbe693e279aeef143))





## [0.1.1](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/@trusted-pdf/sign@0.1.0...@trusted-pdf/sign@0.1.1) (2023-02-22)

**Note:** Version bump only for package @trusted-pdf/sign





# [0.1.0](https://git.digtlab.ru/trusted.ru/trusted-pdf/compare/@trusted-pdf/sign@0.0.1...@trusted-pdf/sign@0.1.0) (2023-02-19)


### Features

* Добавление API для Подписи/Проверки ([f7c2da4](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/f7c2da496af598d82e355c4fbe693e279aeef143))





## 0.0.1 (2023-02-19)


### Bug Fixes

* npm run build ([8181309](https://git.digtlab.ru/trusted.ru/trusted-pdf/commits/8181309986439b00f1f890d21096c855b3a7dac1))
