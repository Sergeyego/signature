import pkg from "./package.json" assert { type: "json" };
import { configure } from "../../rollup.config.mjs";

export default configure(pkg);
