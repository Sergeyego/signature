import { IPdfFlagsParams, PdfFlags } from "@trusted-pdf/pdf";

export class PdfSigFlags extends PdfFlags<typeof SigFlags>{
  public constructor(options?: IPdfFlagsParams<typeof SigFlags>) {
    super(SigFlags, options);
  }
}

export enum SigFlags {
  SignaturesExist = 1 << 0,
  AppendOnly = 1 << 1,
}
