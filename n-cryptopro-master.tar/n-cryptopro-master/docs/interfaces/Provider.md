[n-cryptopro](../README.md) / [Exports](../modules.md) / Provider

# Interface: Provider

## Table of contents

### Methods

- [getContainerName](Provider.md#getcontainername)
- [getName](Provider.md#getname)

## Methods

### getContainerName

▸ **getContainerName**(): `string`

#### Returns

`string`

___

### getName

▸ **getName**(): `string`

#### Returns

`string`
