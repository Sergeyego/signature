module.exports = require('bindings')('cryptopro')
