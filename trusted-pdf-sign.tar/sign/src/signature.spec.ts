import * as assert from "node:assert";
import * as fs from "node:fs";
import * as crypto from "node:crypto";
import * as asn1js from "asn1js";
import * as pkijs from "pkijs";

import * as pdf from "@trusted-pdf/pdf";
import { Sign } from "./sign";

pkijs.setEngine("NodeJS", new pkijs.CryptoEngine({ crypto: crypto.webcrypto as globalThis.Crypto }));

describe("Signature", () => {
  it("find 1 signature box", () => {
    const file = fs.readFileSync(`${__dirname}/../testdata/1_block.pdf`);

    const doc = new pdf.Document();
    doc.read(file);

    const sign = new Sign(doc);

    const sigName = "signature 1";

    const sig1 = sign.findSignature(sigName);
    assert.equal(sig1?.dict.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);

    const sig2 = sign.findSignature(0);
    assert.equal(sig2?.dict.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);

    const sig3 = sign.getSignature(sigName);
    assert.equal(sig3.dict.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);

    const sig4 = sign.getSignature(0);
    assert.equal(sig4.dict.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);

    const list = sign.getSignaturesList();
    assert.equal(list.size, 1);
  });

  it("find 3 signature box", () => {
    const file = fs.readFileSync(`${__dirname}/../testdata/3_block.pdf`);

    const doc = new pdf.Document();
    doc.read(file);

    const sign = new Sign(doc);

    const sig3 = sign.getSignature("Signature11");
    assert.equal(sig3.dict.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);

    const sig4 = sign.getSignature(1);
    assert.equal(sig4.dict.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);

    sig3.dict.get(pdf.Names.T, pdf.PdfString).value = "NewSig";
    doc.save();

    const list = sign.getSignaturesList();
    assert.equal(list.size, 3);
  });

  it("sign signature 1", async () => {
    const file = fs.readFileSync(`${__dirname}/../testdata/1_block.pdf`);

    const doc = new pdf.Document();
    doc.read(file);

    const sign = new Sign(doc);
    const sigName = "signature 1";
    const sig = sign.getSignature(sigName);

    await sig.sign({
      contentLength: 3000,
      onSign: async (content) => {

        return content;
      }
    });
  });

  it("page of signature 1", async () => {
    const file = fs.readFileSync(`${__dirname}/../testdata/1_block.pdf`);

    const doc = new pdf.Document();
    doc.read(file);

    const sign = new Sign(doc);
    const sigName = "signature 1";
    const sig = sign.getSignature(sigName);

    assert.equal(sig.pageNumber, 1);
  });

  describe("visibility", () => {
    it("invisible", async () => {
      const file = fs.readFileSync(`${__dirname}/../testdata/signed.pdf`);

      const doc = new pdf.Document();
      doc.read(file);

      const sign = new Sign(doc);
      const sigName = "signature 1";
      const sig = sign.getSignature(sigName);

      assert.equal(sig.visibility, false);
    });

    it("visible", async () => {
      const file = fs.readFileSync(`${__dirname}/../testdata/1_block.pdf`);

      const doc = new pdf.Document();
      doc.read(file);

      const sign = new Sign(doc);
      const sigName = "signature 1";
      const sig = sign.getSignature(sigName);

      assert.equal(sig.visibility, true);
    });
  });

  it("sign signature 1 and add jpg image", async () => {
    const file = fs.readFileSync(`${__dirname}/../testdata/1_block.pdf`);

    const doc = new pdf.Document();
    doc.read(file);

    // Находим сигнатуру в файле по имени.
    const sign = new Sign(doc);
    const sigName = "signature 1";
    const sig = sign.getSignature(sigName);

    // Добавляем изображение в документ.
    const uuid = "img-1";
    const imageBuf = fs.readFileSync(`${__dirname}/../testdata/shtamp.jpeg`);
    const image = doc.createImage(imageBuf);

    // Получаем объект отображения сигнатуры.
    const n = sig.dict.get(pdf.Names.AP, pdf.PdfDictionary).get(pdf.Names.N, pdf.PdfStream);

    // Добавляем размеры исходного изображения.
    n.set(pdf.Names.BBox, sig.dict.doc.createArray(
      sig.dict.doc.createNumber(0),
      sig.dict.doc.createNumber(0),
      sig.dict.doc.createNumber(image.width),
      sig.dict.doc.createNumber(image.height),
    ));

    // Добавляем контент отображения изображения.
    n.value = pdf.PdfBuffer.stringToRaw(
      `q\n1 0 0 1 0 0 cm\n${image.width} 0 0 ${image.height} 0 0 cm\n/${uuid} Do\nQ`
    );

    // Добавляем изображение в ресурсы.
    n.set(pdf.Names.Resources, sig.dict.doc.createDictionary({
      XObject: sig.dict.doc.createDictionary({
        [uuid]: image.ref(),
      })
    }));

    // Подписываем.
    await sig.sign({
      contentLength: 1300,
      onUpdate: async () => {
        sig.dict
          .get(pdf.Names.V, pdf.PdfDictionary)
          .get(pdf.Names.SubFilter, pdf.PdfName).value = pdf.Names.AdbePkcs7Detached;
      },
      onSign: async (content) => {
        const cert = await createCertificate();
        const cms = await signPkijs(cert, content);

        return new Uint8Array(cms);
      },
    });

    // fs.writeFileSync(`${__dirname}/../testdata/temp.pdf`, doc.buffer.raw);
  });

  it("invisible sign signature 1 with pkijs", async () => {
    // Set crypto engine for PKIjs module
    const doc = pdf.Document.create(pdf.XRefType.XRefTable);

    const pages = doc.xref.trailer.Root.pages;

    // Add page
    const page = doc.createDictionary({
      Type: doc.createName(pdf.Names.Page),
      Resources: doc.createDictionary(),
      MediaBox: doc.createArray(
        doc.createNumber(0),
        doc.createNumber(0),
        doc.createNumber(595.28),
        doc.createNumber(841.89),
      ),
      Parent: pages,
    });
    pages.kids.push(page.ref());
    pages.count = 1;

    const sign = new Sign(doc);

    sign.addSignatures({
      name: "signature 1",
      page: 1,
    });

    // save document
    doc.save();

    const sigName = "signature 1";
    const sig = sign.getSignature(sigName);

    await sig.sign({
      contentLength: 1300,
      onUpdate: async () => {
        sig.dict
          .get(pdf.Names.V, pdf.PdfDictionary)
          .get(pdf.Names.SubFilter, pdf.PdfName).value = pdf.Names.AdbePkcs7Detached;
      },
      onSign: async (content) => {
        const cert = await createCertificate();
        const cms = await signPkijs(cert, content);

        return new Uint8Array(cms);
      },
    });

    const v = sig.dict.get(pdf.Names.V, pdf.PdfDictionary);
    assert.equal(v.get(pdf.Names.Type, pdf.PdfName).value, pdf.Names.Sig);
    assert.equal(v.get(pdf.Names.Filter, pdf.PdfName).value, pdf.Names.AdobePPKLite);
    assert.equal(v.get(pdf.Names.SubFilter, pdf.PdfName).value, pdf.Names.AdbePkcs7Detached);
    assert.ok(v.get(pdf.Names.Contents, pdf.PdfHexString).value);
    assert.equal(v.get(pdf.Names.ByteRange, pdf.PdfArray).length, 4);
    assert.ok(v.get("M", pdf.PdfLiteralString).value);
  });

  it("sign signature 1 with pkijs", async () => {
    // Set crypto engine for PKIjs module
    const doc = pdf.Document.create(pdf.XRefType.XRefTable);

    const pages = doc.xref.trailer.Root.pages;

    // Add page
    const page = doc.createDictionary({
      Type: doc.createName(pdf.Names.Page),
      Resources: doc.createDictionary(),
      MediaBox: doc.createArray(
        doc.createNumber(0),
        doc.createNumber(0),
        doc.createNumber(595.28),
        doc.createNumber(841.89),
      ),
      Parent: pages,
    });
    pages.kids.push(page.ref());
    pages.count = 1;

    const sign = new Sign(doc);

    sign.addSignatures({
      name: "signature 1",
      page: 1,
      rectangle: {
        x: 20,
        y: 750,
        height: 150,
        width: 50,
      },
      stream: Buffer.from("0.5 g\n0 0 150 50 re\nf"),
    });

    // save document
    doc.save();

    const sigName = "signature 1";
    const sig = sign.getSignature(sigName);

    await sig.sign({
      contentLength: 1300,
      onUpdate: async () => {
        sig.dict
          .get(pdf.Names.V, pdf.PdfDictionary)
          .get(pdf.Names.SubFilter, pdf.PdfName).value = pdf.Names.AdbePkcs7Detached;
      },
      onSign: async (content) => {
        const cert = await createCertificate();
        const cms = await signPkijs(cert, content);

        return new Uint8Array(cms);
      },
    });

    const v = sig.dict.get(pdf.Names.V, pdf.PdfDictionary);
    assert.equal(v.get(pdf.Names.Type, pdf.PdfName).value, pdf.Names.Sig);
    assert.equal(v.get(pdf.Names.Filter, pdf.PdfName).value, pdf.Names.AdobePPKLite);
    assert.equal(v.get(pdf.Names.SubFilter, pdf.PdfName).value, pdf.Names.AdbePkcs7Detached);
    assert.ok(v.get(pdf.Names.Contents, pdf.PdfHexString).value);
    assert.equal(v.get(pdf.Names.ByteRange, pdf.PdfArray).length, 4);
    assert.ok(v.get("M", pdf.PdfLiteralString).value);

    const ap = sig.dict.get(pdf.Names.AP, pdf.PdfDictionary);
    const n = ap.get(pdf.Names.N, pdf.PdfStream);
    assert.ok(n.stream);

    // fs.writeFileSync(`${__dirname}/../testdata/signed.pdf`, doc.buffer.raw);
  });

  // - нужен скрипт подписи документа с добавлением JPEG файла. Сейчас у нас рисует закрашенный прямоугольник
  // - создание блока подписи (без подписания) и добавление в него поля "TrustedParams" в котором должен лежать JSON
  // - получение блока подписи из документа, проверка наличия  "TrustedParams" и извлечение JSON

  describe("verifyAttestation()", () => {
    it("signed", async () => {
      const file = fs.readFileSync(`${__dirname}/../testdata/signed.pdf`);
      const doc = new pdf.Document();
      doc.read(file);

      const sign = new Sign(doc);

      const result = sign.verifyAttestation();
      assert.ok(result.status);
    });

    it("check widget", async () => {
      const file = fs.readFileSync(`${__dirname}/../testdata/bad_sign_content.pdf`);
      const doc = new pdf.Document();
      doc.read(file);

      const sign = new Sign(doc);

      const result = sign.verifyAttestation();
      assert.ok(!result.status);
    });

    it("add page", async () => {
      const file = fs.readFileSync(`${__dirname}/../testdata/signed.pdf`);
      const doc = new pdf.Document();
      doc.read(file);
      const pages = doc.xref.trailer.Root.pages;

      const sign = new Sign(doc);

      // Добавляем новую страницу.
      const page2 = doc.createDictionary({
        Type: doc.createName(pdf.Names.Page),
        Resources: doc.createDictionary(),
        MediaBox: doc.createArray(
          doc.createNumber(0),
          doc.createNumber(0),
          doc.createNumber(595.28),
          doc.createNumber(841.89),
        ),
        Parent: pages,
      });
      pages.kids.push(page2.ref());
      pages.count = 2;
      doc.save();

      const result = sign.verifyAttestation();
      assert.ok(!result.status);
    });
  });

  it("verify signature 1", async () => {
    const file = fs.readFileSync(`${__dirname}/../testdata/Untitled.signed.pdf`);

    const doc = new pdf.Document();
    doc.read(file);

    const sign = new Sign(doc);
    // const sigName = "signature 1";
    const sig = sign.getSignature(1);

    const res = await sig.verify({
      onVerify: async (content, cms) => {
        // Read a CMS Signed Data
        const contentInfo = pkijs.ContentInfo.fromBER(cms);
        if (contentInfo.contentType !== pkijs.ContentInfo.SIGNED_DATA) {
          throw new Error("CMS is not Signed Data.");
        }
        const cmsSigned = new pkijs.SignedData({ schema: contentInfo.content });

        // Verify the CMS signature
        const ok = await cmsSigned.verify({
          signer: 0,
          data: content,
        });

        return ok;
      },
    });

    assert.ok(res.verifyCallBack);
  });

  it("certification signature", async () => {
    // Set crypto engine for PKIjs module
    const doc = pdf.Document.create();

    const pages = doc.xref.trailer.Root.pages;

    // Add page
    const page = doc.createDictionary({
      Type: doc.createName(pdf.Names.Page),
      Resources: doc.createDictionary(),
      MediaBox: doc.createArray(
        doc.createNumber(0),
        doc.createNumber(0),
        doc.createNumber(595.28),
        doc.createNumber(841.89),
      ),
      Parent: pages,
    });
    pages.kids.push(page.ref());
    pages.count = 1;

    const sign = new Sign(doc);

    // add invisible signatures
    sign.addSignatures(
      {
        name: "signature 1",
        page: 1,
      },
      {
        name: "signature 2",
        page: 1,
      });

    const sigName = "signature 1";
    const sig = sign.getSignature(sigName);

    await sig.sign({
      contentLength: 1300,
      onUpdate: async () => {
        sig.dict
          .get(pdf.Names.V, pdf.PdfDictionary)
          .get(pdf.Names.SubFilter, pdf.PdfName).value = pdf.Names.AdbePkcs7Detached;

        // add Signature Reference
        sig.dict.get(pdf.Names.V, pdf.PdfDictionary).set("Reference", doc.createArray(
          doc.createDictionary({
            TransformMethod: doc.createName("DocMDP"),
            TransformParams: doc.createDictionary({
              P: doc.createNumber(3),
              Type: doc.createName("TransformParams"),
              V: doc.createName("1.2"),
            }),
            Type: doc.createName("SigRef"),
          })
        ));

        // add Perms to Catalog
        doc.xref.trailer.Root.set(pdf.Names.Perms, doc.createDictionary({ DocMDP: sig.dict.get(pdf.Names.V, pdf.PdfDictionary).ref() }));
      },
      onSign: async (content) => {
        const cert = await createCertificate();

        const cms = await signPkijs(cert, content);

        return new Uint8Array(cms);
      },
    });

    // save document
    doc.save();

    // fs.writeFileSync("C:/Users/User/repos/trusted-pdf/packages/sign/testdata/temp.pdf", doc.buffer.raw);

    const docMDPDict = sig.dict.get(pdf.Names.V, pdf.PdfDictionary).get("Reference", pdf.PdfArray).get(0, pdf.PdfDictionary);
    assert.ok(docMDPDict.get("TransformMethod", pdf.PdfName).value);
    assert.ok(docMDPDict.get(pdf.Names.Type, pdf.PdfName));

    const transformParams = docMDPDict.get("TransformParams", pdf.PdfDictionary);
    assert.ok(transformParams.get(pdf.Names.P, pdf.PdfNumber).value);
    assert.ok(transformParams.get(pdf.Names.Type, pdf.PdfName).value);
    assert.ok(transformParams.get(pdf.Names.V, pdf.PdfName).value);
  });

  async function createCertificate(): Promise<CreateCertificateResult> {
    // Create certificate
    const certificate = new pkijs.Certificate();
    certificate.version = 2;
    certificate.serialNumber = new asn1js.Integer({ value: 1 });
    certificate.issuer.typesAndValues.push(new pkijs.AttributeTypeAndValue({
      type: "2.5.4.3", // Common name
      value: new asn1js.BmpString({ value: "Test" })
    }));
    certificate.subject.typesAndValues.push(new pkijs.AttributeTypeAndValue({
      type: "2.5.4.3", // Common name
      value: new asn1js.BmpString({ value: "Test" })
    }));

    // Set a validity period of 1 year
    certificate.notBefore.value = new Date();
    const notAfter = new Date();
    notAfter.setUTCFullYear(notAfter.getUTCFullYear() + 1);
    certificate.notAfter.value = notAfter;

    certificate.extensions = []; // Extensions are not a part of certificate by default, it's an optional array

    // "BasicConstraints" extension
    const basicConstr = new pkijs.BasicConstraints({
      cA: false,
    });
    certificate.extensions.push(new pkijs.Extension({
      extnID: "2.5.29.19",
      critical: true,
      extnValue: basicConstr.toSchema().toBER(false),
      parsedValue: basicConstr // Parsed value for well-known extensions
    }));

    // "KeyUsage" extension
    const bitArray = new ArrayBuffer(1);
    const bitView = new Uint8Array(bitArray);
    bitView[0] |= 0x80; // Key usage "digitalSignature" flag
    const keyUsage = new asn1js.BitString({ valueHex: bitArray, unusedBits: 7 });
    certificate.extensions.push(new pkijs.Extension({
      extnID: "2.5.29.15",
      critical: true,
      extnValue: keyUsage.toBER(false),
      parsedValue: keyUsage // Parsed value for well-known extensions
    }));
    certificate.extensions.push(new pkijs.Extension({
      extnID: "1.2.840.113583.1.1.10 ",
      critical: false,
      extnValue: new Uint8Array([5, 0]).buffer,
    }));

    // Generate RSA key pair
    const algorithm = {
      name: "RSASSA-PKCS1-v1_5",
      hash: "SHA-256",
      publicExponent: new Uint8Array([1, 0, 1]),
      modulusLength: 2048,
    };
    const keys = await crypto.webcrypto.subtle.generateKey(algorithm, true, ["sign", "verify"]);

    // Exporting public key into "subjectPublicKeyInfo" value of certificate
    await certificate.subjectPublicKeyInfo.importKey(keys.publicKey);

    // Signing final certificate
    await certificate.sign(keys.privateKey, algorithm.hash);

    return {
      certificate,
      keys,
    };
  }

  async function signPkijs(certResult: CreateCertificateResult, data: Uint8Array) {
    // Create a new CMS Signed Data
    const cmsSigned = new pkijs.SignedData({
      encapContentInfo: new pkijs.EncapsulatedContentInfo({
        eContentType: pkijs.ContentInfo.DATA, // "data" content type
        // eContent: new asn1js.OctetString({ valueHex: data })
      }),
      signerInfos: [
        new pkijs.SignerInfo({
          version: 1,
          sid: new pkijs.IssuerAndSerialNumber({
            issuer: certResult.certificate.issuer,
            serialNumber: certResult.certificate.serialNumber
          })
        })
      ],
      // Signer certificate for chain validation
      certificates: [certResult.certificate]
    });

    const msgDigest = await crypto.webcrypto.subtle.digest("SHA-256", data);

    cmsSigned.signerInfos[0].signedAttrs = new pkijs.SignedAndUnsignedAttributes({
      type: 0,
      attributes: [
        new pkijs.Attribute({ type: "1.2.840.113549.1.9.3", values: [new asn1js.ObjectIdentifier({ value: "1.2.840.113549.1.7.1" })] }),
        new pkijs.Attribute({ type: "1.2.840.113549.1.9.4", values: [new asn1js.OctetString({ valueHex: msgDigest })] }),
        new pkijs.Attribute({ type: "1.2.840.113583.1.1.8", values: [new asn1js.Sequence()] }),
      ],
    });

    await cmsSigned.sign(certResult.keys.privateKey, 0, "SHA-256", data);

    // Add Signed Data to Content Info
    const cms = new pkijs.ContentInfo({
      contentType: pkijs.ContentInfo.SIGNED_DATA,
      content: cmsSigned.toSchema(true),
    });

    // Encode CMS to ASN.1
    const cmsRaw = cms.toSchema().toBER();

    return cmsRaw;
  }
});

interface CreateCertificateResult {
  certificate: pkijs.Certificate;
  keys: CryptoKeyPair;
}
