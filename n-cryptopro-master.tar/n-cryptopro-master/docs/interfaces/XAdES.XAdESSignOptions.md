[n-cryptopro](../README.md) / [Exports](../modules.md) / [XAdES](../modules/XAdES.md) / XAdESSignOptions

# Interface: XAdESSignOptions

[XAdES](../modules/XAdES.md).XAdESSignOptions

## Table of contents

### Properties

- [type](XAdES.XAdESSignOptions.md#type)
- [xpath](XAdES.XAdESSignOptions.md#xpath)

## Properties

### type

• `Optional` **type**: `number`

Тип подписи

___

### xpath

• `Optional` **xpath**: `string`

Регулярное выражение для получение узла подписи
