# `@trusted-pdf/sign`

## Пример использования

### Добавление невидимой Signature

```ts
import * as fs from "node:fs";
import * as pdf from "@trusted-pdf/pdf";
import * as pdfSign from "@trusted-pdf/sign";

const buf = fs.readFileSync(`path/to/input.pdf`);

const doc = new pdf.Document();
doc.read(buf);

const sign = new pdfSign.Sign(doc);

// Добавление Сигнатуры.
sign.addSignatures({
  name: "signature 1",
  page: 1,
});

// Сохранение документа.
doc.save();
```

### Добавление Signature

```ts
import * as fs from "node:fs";
import * as pdf from "@trusted-pdf/pdf";
import * as pdfSign from "@trusted-pdf/sign";

const buf = fs.readFileSync(`path/to/input.pdf`);

const doc = new pdf.Document();
doc.read(buf);

const sign = new pdfSign.Sign(doc);

// Добавление Сигнатуры.
sign.addSignatures({
  name: "signature 1",
  page: 1,
  rectangle: {
    x: 20,
    y: 750,
    height: 150,
    width: 50,
  },
  stream: Buffer.from("0.5 g\n0 0 150 50 re\nf"),
});

// Сохранение документа.
doc.save();
```

### Подписание

```ts
import * as fs from "node:fs";
import * as pdf from "@trusted-pdf/pdf";
import * as pdfSign from "@trusted-pdf/sign";

const buf = fs.readFileSync(`path/to/input.pdf`);

const doc = new pdf.Document();
doc.read(buf);

const sign = new pdfSign.Sign(doc);

const sig = sign.getSignature("signature 1");

await sig.sign({
  contentLength: 1300,
  onUpdate: async () => {
    sig.dict
      .get("V", PdfDictionary)
      .set("Name", doc.createLiteral("Иванов И.И."));
  },
  onSign: async (content) => {
    // Подписание Content и формирование блока подписи в формате CMS.
    return new Uint8Array(cms);
  },
});

// Сохранение документа.
doc.save();
```

### Верификация

```ts
import * as fs from "node:fs";
import * as pdf from "@trusted-pdf/pdf";
import * as pdfSign from "@trusted-pdf/sign";

const buf = fs.readFileSync(`path/to/input.pdf`);

const doc = new pdf.Document();
doc.read(buf);

const sign = new pdfSign.Sign(doc);

const sig = sign.getSignature("signature 1");

const res = await sig.verify({
  onVerify: async (content, cms) => {
    // Верификация подписи и контента.
    return status;
  },
});
```