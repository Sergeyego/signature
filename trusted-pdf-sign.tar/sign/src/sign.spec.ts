import * as assert from "node:assert";
import * as fs from "node:fs";

import * as pdf from "@trusted-pdf/pdf";
import { Sign } from "./sign";

function readFile(path: string): Uint8Array {
  if (!fs.existsSync(path)) {
    throw Error("File not found");
  }

  return fs.readFileSync(path);
}

function createDocument(): pdf.Document {
  const doc = pdf.Document.create(pdf.XRefType.XRefTable);

  const catalog = doc.xref.trailer.Root;
  const pages = catalog.pages;

  // Add page
  const page = doc.createDictionary({
    Type: doc.createName(pdf.Names.Page),
    Resources: doc.createDictionary(),
    MediaBox: doc.createArray(
      doc.createNumber(0),
      doc.createNumber(0),
      doc.createNumber(595.28),
      doc.createNumber(841.89),
    ),
    Parent: pages,
  });
  pages.kids.push(page.ref());
  pages.count = 1;

  doc.save();

  return doc;
}

describe("Sign", () => {
  let doc: pdf.Document;
  let sign: Sign;

  beforeEach(() => {
    doc = createDocument();
    sign = new Sign(doc);
  });

  describe(pdf.Names.TrustedParams, () => {
    it("create signature box with TrustedParams", () => {
      const json = "{\"Name\":\"Bob\", \"Data\":12345}";

      sign.addSignatures({
        name: "signature 1",
        page: 1,
        rectangle: {
          x: 20,
          y: 750,
          height: 150,
          width: 50,
        },
        stream: Buffer.from("0.5 g\n0 0 150 50 re\nf"),
        trustedParams: json,
      });

      // сохранение документа.
      doc.save();

      // Получение параметров из сигнатуры.
      assert.equal(sign.getSignature(0).trustedParams, json);
    });

    it("create signature and add TrustedParams", () => {
      const json = "{\"Name\":\"Bob\", \"Data\":12345}";

      sign.addSignatures({
        name: "signature 1",
        page: 1,
        rectangle: {
          x: 20,
          y: 750,
          height: 150,
          width: 50,
        },
        stream: Buffer.from("0.5 g\n0 0 150 50 re\nf"),
      });

      // сохранение документа.
      doc.save();

      const signature = sign.getSignature(0);
      signature.trustedParams = json;

      doc.save();

      // Получение параметров из сигнатуры.
      assert.equal(sign.getSignature(0).trustedParams, json);
    });

    it("create signature with TrustedParams with cyrillic", () => {
      const json = "{\"Name\":\"Аркадий\", \"Data\":12345}";

      sign.addSignatures({
        name: "signature 1",
        page: 1,
        rectangle: {
          x: 20,
          y: 750,
          height: 150,
          width: 50,
        },
        stream: Buffer.from("0.5 g\n0 0 150 50 re\nf"),
        trustedParams: json,
      });

      // сохранение документа.
      doc.save();

      // Получение параметров из сигнатуры.
      assert.equal(sign.getSignature(0).trustedParams, json);
    });

    it("get TrustedParams", () => {
      const json = "{\"Name\":\"Аркадий\", \"Data\":12345}";

      const file = readFile(`${__dirname}/../testdata/1_block_trusted_params.pdf`);
      const doc = new pdf.Document();
      doc.read(file);

      const sign = new Sign(doc);

      assert.equal(sign.getSignature(0).trustedParams, json);
    });

    it("get null", () => {
      const file = readFile(`${__dirname}/../testdata/1_block.pdf`);
      const doc = new pdf.Document();
      doc.read(file);

      const sign = new Sign(doc);

      assert.ok(!sign.getSignature(0).trustedParams);
    });
  });

  it("create 1 signature box", () => {
    const sigList = sign.addSignatures({
      name: "signature 1",
      page: 1,
      rectangle: {
        x: 20,
        y: 750,
        height: 150,
        width: 50,
      },
      stream: Buffer.from("0.5 g\n0 0 150 50 re\nf"),
    });

    // save document
    doc.save();

    // Проверяем возврат метода addSignatures().
    assert.equal(sigList.size, 1);
    // Проверяем добавление sig в общий список signaturess.
    assert.equal(sign.getSignaturesList().size, 1);

    const catalog = doc.xref.trailer.Root;

    const acroForm = catalog.get(pdf.Names.AcroForm, pdf.PdfDictionary);
    assert.equal(acroForm.get(pdf.Names.SigFlags, pdf.PdfNumber).value, 1);
    const fields = acroForm.get(pdf.Names.Fields, pdf.PdfArray);
    assert.equal(fields.length, 1);
    const sig = fields.get(0, pdf.PdfDictionary);
    assert.equal(sig.get(pdf.Names.FT, pdf.PdfName).value, pdf.Names.Sig);
    assert.equal(sig.get(pdf.Names.T, pdf.PdfLiteralString).value, "signature 1");
    assert.equal(sig.get(pdf.Names.F, pdf.PdfNumber).value, 4);
    assert.equal(sig.get(pdf.Names.Type, pdf.PdfName).value, pdf.Names.Annot);
    assert.equal(sig.get(pdf.Names.Subtype, pdf.PdfName).value, pdf.Names.Widget);
    assert.ok(sig.get(pdf.Names.Rect, pdf.PdfArray));
    const form = sig.get(pdf.Names.AP, pdf.PdfDictionary).get(pdf.Names.N, pdf.PdfStream);
    assert.equal(form.get(pdf.Names.Type, pdf.PdfName).value, pdf.Names.XObject);
    assert.equal(form.get(pdf.Names.Subtype, pdf.PdfName).value, pdf.Names.Form);
    assert.equal(form.get(pdf.Names.FormType, pdf.PdfNumber).value, 1);
    assert.ok(form.get(pdf.Names.Resources, pdf.PdfDictionary));
    assert.ok(form.get(pdf.Names.BBox, pdf.PdfArray));
  });

  it("create signature box on bad page", () => {
    assert.throws(() => {
      sign.addSignatures({
        name: "signature 1",
        page: 2,
      });
    });
  });

});
