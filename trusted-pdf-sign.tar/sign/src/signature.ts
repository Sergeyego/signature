import * as pdf from "@trusted-pdf/pdf";
import { PdfSigFlags } from "./sig_flags";

export interface SignOptions {
  contentLength: number;
  /**
   * CallBack функция, дает возможность изменить Signature Dictionary
   * до сохранения документа и формирования Content на подпись.
   * @returns
   */
  onUpdate?: () => Promise<void>;
  /**
   * CallBack функция подписи Content. Возвращаемое значение записывается в значение Content.
   * @returns
   */
  onSign: (content: Uint8Array) => Promise<Uint8Array>;
}

export interface VerifyOptions {
  /**
   * CallBack функция верификации подписи.
   * @param content Проверяемый Content.
   * @param sign Подпись.
   * @returns
   */
  onVerify: (content: Uint8Array, sign: Uint8Array) => Promise<boolean>;
}
export interface VerifyResult {
  verifyCallBack: boolean;
}

export class Signature {
  public constructor(
    public dict: pdf.PdfDictionary,
    public name: string) {
  }

  /**
   * Видимость сигнатуры.
   * Возвращает true если сигнатура видимая и false в противном случае.
   */
  public get visibility(): boolean {
    // Проверяем флаги.
    const f = this.dict.find(pdf.Names.F, pdf.PdfNumber);
    if (f) {
      const flags = this.dict.doc.createFlags(pdf.PdfAnnotFlags, f.value).get();
      if (flags.includes(pdf.AnnotFlagsName.Hidden)
        || flags.includes(pdf.AnnotFlagsName.Invisible)
        || flags.includes(pdf.AnnotFlagsName.NoView)
        || flags.includes(pdf.AnnotFlagsName.ToggleNoView)) {
        return false;
      }
    }

    // Получаем поле rect которое отвечает за размеры сигнатуры.
    const rect = this.dict.get(pdf.Names.Rect, pdf.PdfArray);

    // Если хотя бы одна координата отличается от нуля то сигнатура видима.
    for (const coordinate of rect) {
      if (coordinate instanceof pdf.PdfNumber && coordinate.value != 0) {
        return true;
      }
    }

    return false;
  }

  /**
   * Номер страницы на которой находится сигнатура.
   */
  public get pageNumber(): number {
    // Получаем поле P. Это ссылка на страницу
    const p = this.dict.get(pdf.Names.P, pdf.PdfDictionary);

    // Получаем ID страницы.
    if (!p.parent || !(p.parent instanceof pdf.PdfIndirectObject)) {
      throw new Error("Невозможно получить ID страницы");
    }
    const pID = p.parent.id;

    // Перебираем все страницы по ID чтобы определить номер страницы.
    const list = this.dict.doc.getPagesList();
    const pageNumber = [...list.keys()].find((key) => {
      const dictionary = list.get(key);
      if (!dictionary) {
        throw new Error("Неверный ключ страницы");
      }

      if (!dictionary.parent || !(dictionary.parent instanceof pdf.PdfIndirectObject)) {
        throw new Error("Страница без ID");
      }

      return dictionary.parent.id === pID;
    });

    if (!pageNumber) {
      throw new Error("Страница не найдена");
    }

    return pageNumber;
  }

  public set trustedParams(value: string | null) {
    if (value) {
      this.dict.set(pdf.Names.TrustedParams, this.dict.doc.createLiteral(value));
    }
  }

  public get trustedParams(): string | null {
    const params = this.dict.find(pdf.Names.TrustedParams, pdf.PdfLiteralString);
    if (params) {
      return params.value;
    }

    return params;
  }

  /**
   * Подпись сигнатуры.
   * @param options
   */
  public async sign(options: SignOptions): Promise<void> {
    const doc = this.dict.doc;
    doc.save();

    if (this.dict.find(pdf.Names.V)) {
      throw new Error(`Sign(): Сигнатура '${this.name}' уже подписана`);
    }

    // Добавляем signature в AcroForm.
    const catalog = doc.xref.trailer.Root;
    const acroForm = catalog.findOrSet(pdf.Names.AcroForm, pdf.PdfDictionary, true);

    // Добавляем флаг SigFlags.
    let flags = acroForm.find(pdf.Names.SigFlags, PdfSigFlags);
    if (!flags) {
      flags = doc.createFlags(PdfSigFlags);
      acroForm.set(pdf.Names.SigFlags, flags);
    }

    flags.set("SignaturesExist");
    flags.set("AppendOnly");

    // Определение длинны индексов для ByteRange.
    const count = String(doc.buffer.length).length;
    const padding = count > 10 ? count + 2 : 10;

    // Создание PdfNumber для ByteRange.
    // Начало документа.
    const indexByteRange1 = doc.createNumber(0);
    // Длинна до < начала контента.
    const indexByteRange2 = doc.createNumber(0);
    indexByteRange2.padding = padding;
    // Индекс после > контента.
    const indexByteRange3 = doc.createNumber(0);
    indexByteRange3.padding = padding;
    // Длинна до конца документа.
    const indexByteRange4 = doc.createNumber(0);
    indexByteRange4.padding = padding;

    // Создание Contents.
    const contents = doc.createHexString(new Uint8Array(options.contentLength));

    this.dict.set(pdf.Names.V, doc.createDictionary({
      Type: doc.createName(pdf.Names.Sig),
      Filter: doc.createName(pdf.Names.AdobePPKLite),
      SubFilter: doc.createName(pdf.Names.EtsiCadesDetached),
      Contents: contents,
      ByteRange: doc.createArray(indexByteRange1, indexByteRange2, indexByteRange3, indexByteRange4),
      // D:20221025170800+03'00'
      M: doc.createLiteral(doc.createFormattedDateTime()),
    }).ref());

    // CallBack.
    await options.onUpdate?.();

    // Сохранение документа для формирования RAW.
    doc.save();

    // Заполнение ByteRange.
    indexByteRange2.reWriteValue(contents.raw.offset);
    const indexOfEndContent = contents.raw.offset + contents.raw.length;
    indexByteRange3.reWriteValue(indexOfEndContent);
    indexByteRange4.reWriteValue(doc.buffer.length - indexOfEndContent);

    // Формирование RAW для отправки на подпись.
    const raw1 = doc.buffer.subarray(indexByteRange1.value, indexByteRange1.value + indexByteRange2.value).getRaw();
    const raw2 = doc.buffer.subarray(indexByteRange3.value, indexByteRange3.value + indexByteRange4.value).getRaw();

    const rawContent = new Uint8Array(raw1.length + raw2.length);
    rawContent.set(raw1);
    rawContent.set(raw2, raw1.length);

    // Получение подписи.
    const cms = await options.onSign(rawContent);

    const newCms = new Uint8Array((contents.raw.length - 2) / 2);
    newCms.set(cms, 0);

    // Замена контента.
    contents.reWriteValue(newCms);
  }

  /**
   * Верификация подписи сигнатуры.
   * @param options
   * @returns
   */
  public async verify(options: VerifyOptions): Promise<VerifyResult> {
    // Формируем result.
    const res: VerifyResult = {
      verifyCallBack: false,
    };

    const doc = this.dict.doc;

    // Получаем данные из ByteRange.
    const v = this.dict.get(pdf.Names.V, pdf.PdfDictionary);
    const byteRange = v.get(pdf.Names.ByteRange, pdf.PdfArray);
    const indexByteRange1 = byteRange.get(0, pdf.PdfNumber).value;
    const indexByteRange2 = byteRange.get(1, pdf.PdfNumber).value;
    const indexByteRange3 = byteRange.get(2, pdf.PdfNumber).value;
    const indexByteRange4 = byteRange.get(3, pdf.PdfNumber).value;

    // Формирование RAW для отправки на проверку.
    const raw1 = doc.buffer.subarray(indexByteRange1, indexByteRange1 + indexByteRange2).getRaw();
    const raw2 = doc.buffer.subarray(indexByteRange3, indexByteRange3 + indexByteRange4).getRaw();

    const rawContent = new Uint8Array(raw1.length + raw2.length);
    rawContent.set(raw1);
    rawContent.set(raw2, raw1.length);

    // Получение подписи для отправки на проверку.
    const sign = v.get(pdf.Names.Contents, pdf.PdfHexString).toBinary();

    res.verifyCallBack = await options.onVerify(rawContent, sign);

    return res;
  }
}
