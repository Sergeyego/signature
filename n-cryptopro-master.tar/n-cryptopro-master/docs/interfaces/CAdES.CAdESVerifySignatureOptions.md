[n-cryptopro](../README.md) / [Exports](../modules.md) / [CAdES](../modules/CAdES.md) / CAdESVerifySignatureOptions

# Interface: CAdESVerifySignatureOptions

[CAdES](../modules/CAdES.md).CAdESVerifySignatureOptions

## Table of contents

### Properties

- [type](CAdES.CAdESVerifySignatureOptions.md#type)

## Properties

### type

• **type**: `string`

Тип подписи
