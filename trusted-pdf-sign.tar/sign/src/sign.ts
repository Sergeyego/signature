import * as pdf from "@trusted-pdf/pdf";
import { Signature } from "./signature";
import { PdfSigFlags } from "./sig_flags";

interface IRectangle {
  x: number;
  y: number;
  height: number;
  width: number;
}

export interface ISignatureParams {
  page: number;
  name: string;
  rectangle?: Partial<IRectangle>;
  stream?: Uint8Array;
  trustedParams?: string;
}

export type SignatureList = ReadonlyMap<string, Signature>;

export interface ResultVerifyAttestation {
  status: boolean;
  log: string[];
}

export class Sign {
  #signatures: Map<string, Signature> = new Map();

  private static DEFAULT_RECT: IRectangle = { x: 0, y: 0, height: 0, width: 0 };

  public constructor(
    public doc: pdf.Document,
  ) {
    this.findSignaturesInDocument();
  }

  /**
   * Проверяет были ли внесены изменения в контент после первой подписи.
   * @returns
   */
  public verifyAttestation(): ResultVerifyAttestation {
    let status = true;
    const log: string[] = [];

    // Получение всех xref.
    const listXref = [this.doc.xref];
    let current = this.doc.xref;
    while (true) {
      if (!current.prev) {
        break;
      }

      listXref.push(current.prev);
      current = current.prev;
    }

    // Разворот массива.
    listXref.reverse();

    const listPagesAndContents: number[] = [];
    const listWidgets = new Map<number, Array<number>>();
    let find = false;

    for (const xref of listXref) {
      if (find) {
        // Проверка последующих обновлений на изменения.
        for (const [key, obj] of xref.objects) {
          if (listPagesAndContents.includes(key)) {
            status = false;
            log.push(`Объект ${key} был изменен`);
          }

          // Проверка изменения Rect у виджетов.
          const oldRect = listWidgets.get(key);
          if (oldRect) {
            // Проверяем что это виджет.
            if (!(obj.value instanceof pdf.PdfDictionary)) {
              log.push(`Виджет ${key} перестал быть Dictionary`);
              status = false;

              return { status, log };
            }
            const subtype = obj.value.find(pdf.Names.Subtype, pdf.PdfName);
            if (!subtype || subtype.value !== pdf.Names.Widget) {
              log.push(`Виджет ${key} перестал быть Widget`);
              status = false;

              return { status, log };
            }

            const newRect = this.getRect(obj.value);

            // Сравнение Rect.
            if (oldRect.toString() !== newRect.toString()) {
              log.push(`Виджет ${key} изменил rect ${oldRect} на rect ${newRect}`);
              status = false;

              return { status, log };
            }
          }
        }
      }

      if (!find) {
        // Поиск первой sig и формирование списка Страниц и их Контента на момент добавления первой sig.
        for (const [key, obj] of xref.objects) {
          const value = obj.getValue(xref);
          if (value instanceof pdf.PdfDictionary) {
            const type = value.find(pdf.Names.Type, pdf.PdfName);
            if (type) {
              if (type.value === pdf.Names.Pages) {
                listPagesAndContents.push(key);
                continue;
              }

              if (type.value === pdf.Names.Page) {
                listPagesAndContents.push(key);

                this.findWidgetsRectOnPage(xref, value, listWidgets);

                const contents = value.find(pdf.Names.Contents);
                if (contents && contents.parent && contents.parent instanceof pdf.PdfIndirectObject) {
                  listPagesAndContents.push(contents.parent.id);
                }
                continue;
              }

              if (type.value.toLowerCase() === "sig") {
                find = true;
              }
            }
          }
        }
      }
    }

    if (!find) {
      status = false;
      log.push("Подписи не найдены");
    }

    return { status, log };
  }

  /**
   * Ищет все виджеты страницы и заполняет список map.
   * @param map
   * @param page
   * @returns
   */
  private findWidgetsRectOnPage(xref: pdf.XRef, page: pdf.PdfDictionary, map?: Map<number, Array<number>>): (Map<number, Array<number>> | null) {
    // Получаем список аннотаций.
    const annots = page.find(pdf.Names.Annots, pdf.PdfArray);
    if (!annots) {
      return null;
    }

    if (!map) {
      map = new Map();
    }

    // Перебираем аннотации.
    for (let index = 0; index < annots.length; index++) {
      const annot = annots.get(index, pdf.PdfDictionary);

      // Выбираем виджеты.
      const subtype = annot.find(pdf.Names.Subtype, pdf.PdfName);
      if (!subtype || subtype.value !== pdf.Names.Widget) {
        break;
      }

      // Получаем ID аннотации.
      if (!annot.parent || !(annot.parent instanceof pdf.PdfIndirectObject)) {
        break;
      }
      const id = annot.parent.id;
      const history = xref.objects.get(id);
      if (!history || !(history.value instanceof pdf.PdfDictionary)) {
        throw new Error(`Невозможно получить аннотацию ${id} из обновления`);
      }

      const arr = this.getRect(history.value);

      // Добавляем в список.
      map.set(id, arr);
    }

    if (!map.size) {
      return null;
    }

    return map;
  }

  private getRect(obj: pdf.PdfDictionary): Array<number> {
    const arr = new Array<number>();

    // Проверяем наличие rect.
    const rect = obj.find(pdf.Names.Rect, pdf.PdfArray);
    if (!rect) {
      return arr;
    }

    // Формируем массив значений rect.
    for (let index = 0; index < rect.length; index++) {
      const element = rect.get(index, pdf.PdfNumber).value;
      arr.push(element);
    }

    return arr;
  }

  /**
   * Поиск всех сигнатур в документе.
   * @returns
   */
  private findSignaturesInDocument(): void {
    const catalog = this.doc.xref.trailer.Root;

    const acroForm = catalog.find(pdf.Names.AcroForm, pdf.PdfDictionary);
    if (!acroForm) {
      return;
    }

    const fields = acroForm.get(pdf.Names.Fields, pdf.PdfArray);

    // Перебираем все fields и проверяем на обязательное поле FT.
    for (let index = 0; index < fields.length; index++) {
      const dict = fields.get(index, pdf.PdfDictionary);
      const ft = dict.find(pdf.Names.FT, pdf.PdfName);

      if (!ft || ft.value !== pdf.Names.Sig) {
        continue;
      }

      // Получаем имя сигнатуры.
      const name = dict.get(pdf.Names.T, pdf.PdfString).value;

      // Добавляем в общий список.
      this.#signatures.set(name, new Signature(dict, name));
    }
  }

  /**
   * Возвращает список всех сигнатур документа.
   * @returns
   */
  public getSignaturesList(): SignatureList {
    return this.#signatures;
  }

  /**
   * Поиск сигнатуры по имени или индексу.
   * Индексы начинаются с 0.
   * @param key Имя или индекс сигнатуры.
   */
  public findSignature(key: string | number): Signature | null {
    if (typeof key === "string") {
      return this.#signatures.get(key) ?? null;
    }

    const keys = Array.from(this.#signatures.keys());

    return this.#signatures.get(keys[key]) ?? null;
  }

  /**
   * Получение сигнатуры по имени или индексу.
   * Индексы начинаются с 0.
   * @param key Имя или индекс сигнатуры.
   */
  public getSignature(key: string | number): Signature {
    const sig = this.findSignature(key);
    if (!sig) {
      throw new Error(`${key} signature не найдена`);
    }

    return sig;
  }

  /**
   * Добавление сигнатуры или массива сигнатур в документ.
   * @param params Параметры добавления.
   * @returns Возвращает список добавленных сигнатур.
   */
  public addSignatures(...params: ISignatureParams[]): SignatureList {
    // Проверка входящих параметров.
    if (!params.length) {
      throw new Error("addSignature(): должен содержать параметры");
    }

    const pages = this.doc.getPagesList();
    const list: Map<string, Signature> = new Map();

    // Создание сигнатур по параметрам.
    for (const param of params) {
      // Получаем страницу.
      const page = pages.get(param.page);
      if (!page) {
        throw new Error(`Страница ${param.page} не найдена`);
      }

      // Проверка на уникальность имени.
      if (this.#signatures.has(param.name)) {
        throw new Error(`Сигнатура с имененем ${param.name}, не найдена`);
      }

      // Создание сигнатуры.
      const sigDict = this.addSignatureOnPage(page, param.name, Object.assign({}, Sign.DEFAULT_RECT, param.rectangle), param.stream);
      const sig = new Signature(sigDict, param.name);
      if (param.trustedParams) {
        sig.trustedParams = param.trustedParams;
      }

      // Добавление сигнатуры в список.
      this.#signatures.set(param.name, sig);

      // Добавление сигнатуры в список для возврата.
      list.set(param.name, sig);
    }

    return list;
  }

  /**
   * Добавление сигнатуры на страницу.
   * @param page
   * @param name
   * @param rectangle
   * @param stream
   * @returns
   */
  private addSignatureOnPage(page: pdf.PdfDictionary, name: string, rectangle: IRectangle, stream = new Uint8Array()): pdf.PdfDictionary {
    const catalog = this.doc.xref.trailer.Root;

    // Проверяем не пустое ли имя сигнатуры.
    let sigName = name.trim();
    if (sigName === "") {
      // generate GUID using Math
      sigName = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        // tslint:disable-next-line: no-bitwise
        const r = Math.random() * 16 | 0;
        // tslint:disable-next-line: no-bitwise
        const v = c === "x" ? r : (r & 0x3 | 0x8);

        return v.toString(16);
      });
    }

    // Create Sig
    const sig = this.doc.createDictionary({
      // filed
      FT: this.doc.createName(pdf.Names.Sig),
      T: this.doc.createLiteral(sigName),
      F: this.doc.createNumber(4),
      // annot
      Type: this.doc.createName(pdf.Names.Annot),
      Subtype: this.doc.createName(pdf.Names.Widget),
      P: page.ref(),

      Rect: this.doc.createArray(
        this.doc.createNumber(rectangle.x),
        this.doc.createNumber(rectangle.y),
        this.doc.createNumber(rectangle.x + rectangle.width),
        this.doc.createNumber(rectangle.y + rectangle.height),
      ),
    });

    // Добавляем AP если есть Rectangle.
    if (rectangle.height || rectangle.width) {
      sig.set(pdf.Names.AP, this.doc.createDictionary({
        N: this.doc.createStream({
          dict: {
            Type: this.doc.createName(pdf.Names.XObject),
            Subtype: this.doc.createName(pdf.Names.Form),
            BBox: this.doc.createArray(
              this.doc.createNumber(0),
              this.doc.createNumber(0),
              this.doc.createNumber(rectangle.width),
              this.doc.createNumber(rectangle.height),
            ),
            FormType: this.doc.createNumber(1),
            Resources: this.doc.createDictionary(),
          },
          stream: stream,
        }).ref(),
      }));
    }

    // Добавляем signature в аннотации страницы.
    page
      .findOrSet(pdf.Names.Annots, pdf.PdfArray)
      .push(sig.ref());

    // Добавляем signature в AcroForm.
    const acroForm = catalog.findOrSet(pdf.Names.AcroForm, pdf.PdfDictionary, true);
    acroForm.findOrSet(pdf.Names.Fields, pdf.PdfArray).push(sig.ref());

    // Добавляем флаг SigFlags.
    let sigFlags = acroForm.find(pdf.Names.SigFlags, PdfSigFlags);
    if (!sigFlags) {
      sigFlags = this.doc.createFlags(PdfSigFlags);
      acroForm.set(pdf.Names.SigFlags, sigFlags);
    }
    sigFlags.set("SignaturesExist");

    return sig;
  }
}
